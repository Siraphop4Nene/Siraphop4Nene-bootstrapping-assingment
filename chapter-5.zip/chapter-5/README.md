# Chapter-5

Code and examples for Chapter 5 of [Bootstrapping Microservices](https://www.bootstrapping-microservices.com).

In chapter 5 you learn how to make microservices communicate with direct and indirect messages and how to get whole application "live reload" working.

Please see README in each sub-directory for instructions on starting the particular example.

[Click here to support my work](https://www.codecapers.com.au/about#support-my-work)
